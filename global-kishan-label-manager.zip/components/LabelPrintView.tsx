
import React from 'react';
import { QRCodeSVG } from 'qrcode.react';
import Barcode from 'react-barcode';
import { Delivery, CompanySettings } from '../types';

interface LabelPrintViewProps {
  deliveries: Delivery[];
  settings: CompanySettings;
}

const LabelPrintView: React.FC<LabelPrintViewProps> = ({ deliveries, settings }) => {
  const pages = [];
  for (let i = 0; i < deliveries.length; i += 2) {
    pages.push(deliveries.slice(i, i + 2));
  }

  const getSlipLabel = (type: string) => {
    switch (type) {
      case 'Sample': return 'SAMPLES (नमुना)';
      case 'Standard': return 'STANDARD (स्तर)';
      default: return 'GENERAL (सामान्य)';
    }
  };

  // Clean website URL for display
  const displayUrl = settings.website.replace(/^https?:\/\/(www\.)?/, '').replace(/\/$/, '');

  return (
    <div className="w-full bg-white text-black p-0 print:p-0">
      {pages.map((pageDeliveries, pageIdx) => (
        <div key={pageIdx} className="w-[210mm] h-[297mm] mx-auto overflow-hidden flex flex-col items-center py-[10mm] print:m-0 break-after-page">
          {pageDeliveries.map((delivery, dIdx) => (
            <div 
              key={delivery.id} 
              className={`w-[152.4mm] h-[101.6mm] border-2 border-black mb-[15mm] relative flex flex-col bg-white overflow-hidden p-3 ${dIdx === 1 ? 'mb-0' : ''}`}
            >
              {/* Slip Type Badge */}
              <div className="absolute top-0 right-1/4 bg-black text-white px-3 py-1 rounded-b-lg text-[10px] font-black z-20 shadow-sm border-x border-b border-gray-400">
                {getSlipLabel(delivery.slipType || 'General')}
              </div>

              {/* Watermark */}
              <div className="absolute inset-0 flex items-center justify-center opacity-[0.05] pointer-events-none z-0">
                <img src={settings.logo} alt="" className="w-1/2 h-auto max-h-[70%] object-contain grayscale" />
              </div>

              <div className="relative z-10 flex flex-col h-full">
                {/* Header Row */}
                <div className="flex justify-between items-start border-b border-gray-300 pb-1.5 mb-1.5">
                  <div className="flex gap-2">
                    <img src={settings.logo} alt="Logo" className="w-12 h-12 object-contain bg-white rounded border border-gray-100" />
                    <div>
                      <h1 className="text-lg font-black text-[#1f7a3f] leading-none">{settings.name}</h1>
                      <p className="text-[9px] text-gray-600 mt-0.5 font-bold italic line-clamp-1">{settings.tagline}</p>
                      <p className="text-[8px] text-gray-500 mt-0.5">{settings.address} • {settings.phone}</p>
                    </div>
                  </div>
                  <div className="flex flex-col items-end">
                    <QRCodeSVG value={settings.website} size={45} level="H" />
                    <span className="text-[7px] font-bold mt-0.5 text-gray-400">{displayUrl}</span>
                  </div>
                </div>

                {/* Tracking Row */}
                <div className="flex items-center justify-between gap-4 mb-2 bg-gray-50/50 p-1.5 rounded border border-gray-100">
                   <div className="flex-1">
                      <p className="text-[9px] font-bold text-gray-400 uppercase tracking-tighter nepali-font leading-none mb-0.5">अर्डर आइडी / ORDER ID</p>
                      <h2 className="text-md font-black font-mono tracking-tight">{delivery.orderId}</h2>
                   </div>
                   <div className="bg-white px-1.5 py-0.5 rounded border border-gray-200">
                      <Barcode 
                        value={delivery.orderId} 
                        width={1.0} 
                        height={25} 
                        fontSize={10} 
                        margin={0}
                        displayValue={false}
                      />
                   </div>
                </div>

                {/* Customer & Items Split */}
                <div className="grid grid-cols-5 gap-3 flex-1 overflow-hidden">
                  {/* Left: Customer Info */}
                  <div className="col-span-2 space-y-2 border-r border-gray-200 pr-2">
                    <div>
                      <p className="text-[8px] font-bold text-gray-400 uppercase nepali-font">ग्राहक / TO:</p>
                      <p className="text-[13px] font-black leading-tight uppercase line-clamp-1">{delivery.customerName}</p>
                      <p className="text-[10px] font-bold leading-none mt-0.5">{delivery.phone}</p>
                    </div>
                    <div>
                      <p className="text-[8px] font-bold text-gray-400 uppercase nepali-font">ठेगाना / ADDRESS:</p>
                      <p className="text-[10px] font-bold leading-tight uppercase line-clamp-3">{delivery.address}</p>
                    </div>
                    <div className="pt-1">
                       <div className="bg-gray-100 p-1 rounded inline-block">
                        <p className="text-[8px] font-bold text-gray-500 uppercase nepali-font">तौल / WEIGHT</p>
                        <p className="text-[10px] font-black">{delivery.weight} KG</p>
                      </div>
                    </div>
                  </div>

                  {/* Right: Items Table & Totals */}
                  <div className="col-span-3 flex flex-col h-full">
                    {/* Items List */}
                    <div className="flex-1 overflow-hidden border border-gray-100 rounded bg-white/50">
                      <table className="w-full text-[9px]">
                        <thead>
                          <tr className="bg-gray-100 font-bold border-b border-gray-200">
                            <th className="text-left px-1.5 py-0.5 nepali-font">सामग्री / ITEM</th>
                            <th className="text-center px-1.5 py-0.5">QTY</th>
                            <th className="text-right px-1.5 py-0.5">RATE</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-50">
                          {delivery.items.map((item, idx) => (
                            <tr key={idx}>
                              <td className="px-1.5 py-0.5 truncate max-w-[80px] font-semibold">{item.name}</td>
                              <td className="px-1.5 py-0.5 text-center font-bold">{item.quantity}</td>
                              <td className="px-1.5 py-0.5 text-right font-bold">{item.rate.toLocaleString()}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>

                    {/* Financial Summary */}
                    <div className="mt-1.5 space-y-0.5">
                       <div className="flex justify-between text-[8px] font-bold text-gray-500 px-1">
                          <span>Sub-Total:</span>
                          <span>Rs. {delivery.subTotal.toLocaleString()}</span>
                       </div>
                       <div className="flex justify-between text-[8px] font-bold text-blue-600 px-1">
                          <span>VAT ({delivery.vatRate}%):</span>
                          <span>+ Rs. {delivery.vatAmount.toLocaleString()}</span>
                       </div>
                       <div className="bg-black text-white p-1.5 rounded flex flex-col items-center">
                          <p className="text-[8px] font-bold uppercase nepali-font opacity-80 leading-none">भुक्तानी गर्न बाँकी / TOTAL COLLECT</p>
                          <p className="text-xl font-black leading-none mt-1">Rs. {delivery.grandTotal.toLocaleString()}</p>
                          <div className="flex justify-between w-full mt-1 px-1 opacity-80">
                             <span className="text-[7px] font-bold">Method: {delivery.paymentMethod}</span>
                             <span className="text-[7px] font-bold italic">Date: {new Date(delivery.createdAt).toLocaleDateString()}</span>
                          </div>
                       </div>
                    </div>
                  </div>
                </div>

                {/* Footer Section with Website and Phone */}
                <div className="mt-auto border-t border-dashed border-gray-200 pt-1 flex justify-between items-center text-[7px] font-bold text-gray-400">
                   <div className="flex items-center gap-1">
                     <span className="text-[8px]">🌐</span> {displayUrl}
                   </div>
                   <div className="truncate max-w-[50%] px-1 italic">
                     {settings.tagline}
                   </div>
                   <div className="flex items-center gap-1">
                     <span className="text-[8px]">📞</span> {settings.phone}
                   </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
};

export default LabelPrintView;
