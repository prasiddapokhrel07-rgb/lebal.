
import React from 'react';
/* Added missing icon imports from lucide-react */
import { ShoppingCart, Package, Printer, TrendingUp, Clock, ChevronRight, Sprout, PlusCircle, List } from 'lucide-react';
import { Delivery, CompanySettings } from '../types';

interface DashboardProps {
  deliveries: Delivery[];
  settings: CompanySettings;
  onNewOrder: () => void;
  onViewAll: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ deliveries, settings, onNewOrder, onViewAll }) => {
  const totalDeliveries = deliveries.length;
  const totalWeight = deliveries.reduce((acc, d) => acc + d.weight, 0);
  const printedOrders = deliveries.filter(d => d.status === 'Printed').length;
  const recentOrders = deliveries.slice(0, 5);

  const stats = [
    { label: 'Total Orders', value: totalDeliveries, icon: ShoppingCart, color: 'bg-blue-500' },
    { label: 'Total Weight', value: `${totalWeight.toFixed(1)} kg`, icon: Package, color: 'bg-green-500' },
    { label: 'Printed Labels', value: printedOrders, icon: Printer, color: 'bg-[#1f7a3f]' },
    { label: 'Pending', value: totalDeliveries - printedOrders, icon: Clock, color: 'bg-amber-500' },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Welcome Back, Admin</h1>
          <p className="text-gray-500">Manage your Global Kishan deliveries efficiently.</p>
        </div>
        <button 
          onClick={onNewOrder}
          className="bg-[#1f7a3f] text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-[#165a2e] transition-all shadow-lg"
        >
          <ShoppingCart className="w-5 h-5" />
          Create New Order
        </button>
      </header>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-all">
            <div className="flex items-center justify-between mb-4">
              <div className={`${stat.color} p-3 rounded-xl`}>
                <stat.icon className="w-6 h-6 text-white" />
              </div>
              <TrendingUp className="w-5 h-5 text-gray-300" />
            </div>
            <p className="text-sm font-medium text-gray-500 uppercase tracking-wider">{stat.label}</p>
            <h3 className="text-2xl font-bold text-gray-900 mt-1">{stat.value}</h3>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Deliveries */}
        <div className="lg:col-span-2 bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-50 flex justify-between items-center">
            <h2 className="text-xl font-bold text-gray-900">Recent Deliveries</h2>
            <button 
              onClick={onViewAll}
              className="text-[#1f7a3f] font-semibold text-sm flex items-center hover:underline"
            >
              View All <ChevronRight className="w-4 h-4 ml-1" />
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-gray-50 text-gray-500 text-xs uppercase font-bold tracking-wider">
                  <th className="px-6 py-3">Order ID</th>
                  <th className="px-6 py-3">Customer</th>
                  <th className="px-6 py-3">Weight</th>
                  <th className="px-6 py-3">Status</th>
                  <th className="px-6 py-3">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {recentOrders.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-6 py-10 text-center text-gray-400 italic">No recent orders found.</td>
                  </tr>
                ) : (
                  recentOrders.map((order) => (
                    <tr key={order.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-6 py-4 font-mono text-sm font-bold text-[#1f7a3f]">{order.orderId}</td>
                      <td className="px-6 py-4">
                        <div className="text-sm font-bold text-gray-900">{order.customerName}</div>
                        <div className="text-xs text-gray-500">{order.phone}</div>
                      </td>
                      <td className="px-6 py-4 text-sm">{order.weight} kg</td>
                      <td className="px-6 py-4">
                        <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                          order.status === 'Printed' ? 'bg-green-100 text-green-700' : 
                          order.status === 'Shipped' ? 'bg-blue-100 text-blue-700' : 'bg-amber-100 text-amber-700'
                        }`}>
                          {order.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-500">
                        {new Date(order.createdAt).toLocaleDateString()}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Company Quick Info */}
        <div className="space-y-6">
          <div className="bg-[#1f7a3f] text-white p-6 rounded-2xl shadow-lg relative overflow-hidden">
            <div className="relative z-10">
              <h2 className="text-xl font-bold mb-4">Store Info</h2>
              <div className="space-y-4">
                <div className="flex gap-4">
                  <div className="bg-white/20 p-2 rounded-lg h-fit">
                    <Package className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="text-xs text-white/70 uppercase font-bold tracking-tight">Company</p>
                    <p className="font-semibold">{settings.name}</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="bg-white/20 p-2 rounded-lg h-fit">
                    <Clock className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="text-xs text-white/70 uppercase font-bold tracking-tight">Address</p>
                    <p className="font-semibold text-sm">{settings.address}</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="absolute -right-8 -bottom-8 opacity-10">
              <Sprout className="w-48 h-48" />
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <h2 className="text-lg font-bold text-gray-900 mb-4">Quick Actions</h2>
            <div className="grid grid-cols-2 gap-4">
              <button 
                onClick={onNewOrder}
                className="flex flex-col items-center justify-center gap-2 p-4 rounded-xl border-2 border-dashed border-gray-200 hover:border-[#1f7a3f] hover:bg-green-50 transition-all text-gray-500 hover:text-[#1f7a3f]"
              >
                <PlusCircle className="w-6 h-6" />
                <span className="text-xs font-bold uppercase">New Order</span>
              </button>
              <button 
                onClick={onViewAll}
                className="flex flex-col items-center justify-center gap-2 p-4 rounded-xl border-2 border-dashed border-gray-200 hover:border-[#1f7a3f] hover:bg-green-50 transition-all text-gray-500 hover:text-[#1f7a3f]"
              >
                <List className="w-6 h-6" />
                <span className="text-xs font-bold uppercase">Manage</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
