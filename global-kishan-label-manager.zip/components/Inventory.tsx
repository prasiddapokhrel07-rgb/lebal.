
import React, { useState } from 'react';
import { Plus, Trash2, Edit3, Save, Search, Box, Tag, Sprout } from 'lucide-react';
import { InventoryProduct } from '../types';

interface InventoryProps {
  products: InventoryProduct[];
  onUpdate: (products: InventoryProduct[]) => void;
}

const Inventory: React.FC<InventoryProps> = ({ products, onUpdate }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newName, setNewName] = useState('');
  const [newRate, setNewRate] = useState<number>(0);

  const handleAdd = () => {
    if (!newName) return;
    const newProduct: InventoryProduct = {
      id: Date.now().toString(),
      name: newName,
      defaultRate: newRate
    };
    onUpdate([newProduct, ...products]);
    setNewName('');
    setNewRate(0);
  };

  const handleDelete = (id: string) => {
    onUpdate(products.filter(p => p.id !== id));
  };

  const handleSaveEdit = (id: string) => {
    onUpdate(products.map(p => p.id === id ? { ...p, name: newName, defaultRate: newRate } : p));
    setEditingId(null);
    setNewName('');
    setNewRate(0);
  };

  const startEdit = (p: InventoryProduct) => {
    setEditingId(p.id);
    setNewName(p.name);
    setNewRate(p.defaultRate);
  };

  const filtered = products.filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()));

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Product Inventory (माल विवरण)</h1>
        <p className="text-gray-500">Add products here to quickly select them during order creation.</p>
      </div>

      <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
        <h2 className="text-lg font-bold text-[#1f7a3f] mb-4 flex items-center gap-2">
          <Plus className="w-5 h-5" /> Add New Product
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
          <div className="md:col-span-6">
            <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Product Name (सामग्री नाम)</label>
            <input 
              type="text" 
              value={editingId ? '' : newName} 
              onChange={(e) => !editingId && setNewName(e.target.value)}
              placeholder="e.g. Tomato Seeds Hybrid"
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#1f7a3f] outline-none"
              disabled={!!editingId}
            />
          </div>
          <div className="md:col-span-4">
            <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Default Rate (दर)</label>
            <input 
              type="number" 
              value={editingId ? 0 : newRate} 
              onChange={(e) => !editingId && setNewRate(parseFloat(e.target.value) || 0)}
              className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#1f7a3f] outline-none"
              disabled={!!editingId}
            />
          </div>
          <div className="md:col-span-2">
            <button 
              onClick={handleAdd}
              disabled={!!editingId || !newName}
              className="w-full bg-[#1f7a3f] text-white py-3.5 rounded-xl font-bold hover:bg-[#165a2e] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Add Product
            </button>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-4 border-b border-gray-50 flex flex-col md:flex-row gap-4 items-center">
          <div className="relative flex-1 w-full">
            <Search className="absolute left-4 top-3 w-5 h-5 text-gray-400" />
            <input 
              type="text"
              placeholder="Search products..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#1f7a3f] outline-none"
            />
          </div>
          <div className="text-sm font-bold text-gray-400">
            Total: {filtered.length}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-gray-50 text-gray-500 text-xs uppercase font-bold tracking-wider">
                <th className="px-6 py-4">Product Name</th>
                <th className="px-6 py-4">Standard Rate</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filtered.map(p => (
                <tr key={p.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    {editingId === p.id ? (
                      <input 
                        type="text" 
                        value={newName} 
                        onChange={(e) => setNewName(e.target.value)}
                        className="w-full px-3 py-1.5 border border-gray-200 rounded-lg focus:ring-1 focus:ring-[#1f7a3f] outline-none"
                      />
                    ) : (
                      <div className="flex items-center gap-2">
                        <Box className="w-4 h-4 text-gray-300" />
                        <span className="font-bold text-gray-800">{p.name}</span>
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    {editingId === p.id ? (
                      <input 
                        type="number" 
                        value={newRate} 
                        onChange={(e) => setNewRate(parseFloat(e.target.value) || 0)}
                        className="w-32 px-3 py-1.5 border border-gray-200 rounded-lg focus:ring-1 focus:ring-[#1f7a3f] outline-none"
                      />
                    ) : (
                      <span className="font-mono text-gray-600">Rs. {p.defaultRate.toLocaleString()}</span>
                    )}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end gap-2">
                      {editingId === p.id ? (
                        <button 
                          onClick={() => handleSaveEdit(p.id)}
                          className="p-2 text-green-600 hover:bg-green-50 rounded-lg"
                        >
                          <Save className="w-5 h-5" />
                        </button>
                      ) : (
                        <button 
                          onClick={() => startEdit(p)}
                          className="p-2 text-amber-500 hover:bg-amber-50 rounded-lg"
                        >
                          <Edit3 className="w-5 h-5" />
                        </button>
                      )}
                      <button 
                        onClick={() => handleDelete(p.id)}
                        className="p-2 text-red-400 hover:bg-red-50 rounded-lg"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={3} className="px-6 py-12 text-center text-gray-400 italic">
                    No products found. Add some above.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Inventory;
