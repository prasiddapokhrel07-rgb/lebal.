
import React, { useState, useEffect, useMemo } from 'react';
import { Plus, Trash2, Save, ShoppingBag, User, MapPin, Phone, Truck, RefreshCw, Calculator, Percent, Sprout, Tag, Search } from 'lucide-react';
import { Delivery, ProductItem, SlipType, InventoryProduct } from '../types';

interface DeliveryFormProps {
  onSubmit: (delivery: Delivery) => void;
  initialData?: Delivery | null;
  inventoryProducts: InventoryProduct[];
}

const DeliveryForm: React.FC<DeliveryFormProps> = ({ onSubmit, initialData, inventoryProducts }) => {
  const [orderId, setOrderId] = useState('');
  const [slipType, setSlipType] = useState<SlipType>('General');
  const [customerName, setCustomerName] = useState('');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [items, setItems] = useState<ProductItem[]>([{ id: '1', name: '', quantity: 1, rate: 0, total: 0 }]);
  const [weight, setWeight] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<Delivery['paymentMethod']>('COD');
  const [vatRate, setVatRate] = useState<number>(13); 

  useEffect(() => {
    if (initialData) {
      setOrderId(initialData.orderId);
      setSlipType(initialData.slipType || 'General');
      setCustomerName(initialData.customerName);
      setAddress(initialData.address);
      setPhone(initialData.phone);
      setItems(initialData.items.length > 0 ? initialData.items : [{ id: '1', name: '', quantity: 1, rate: 0, total: 0 }]);
      setWeight(initialData.weight);
      setPaymentMethod(initialData.paymentMethod);
      setVatRate(initialData.vatRate || 0);
    } else {
      setOrderId(`GK-${Math.floor(100000 + Math.random() * 900000)}`);
      setSlipType('General');
      setCustomerName('');
      setAddress('');
      setPhone('');
      setItems([{ id: '1', name: '', quantity: 1, rate: 0, total: 0 }]);
      setWeight(0);
      setPaymentMethod('COD');
      setVatRate(13);
    }
  }, [initialData]);

  const totals = useMemo(() => {
    const subTotal = items.reduce((sum, item) => sum + (item.quantity * item.rate), 0);
    const vatAmount = subTotal * (vatRate / 100);
    const grandTotal = subTotal + vatAmount;
    return { subTotal, vatAmount, grandTotal };
  }, [items, vatRate]);

  const addItem = (name = '', rate = 0) => {
    const lastItem = items[items.length - 1];
    if (lastItem && lastItem.name === '' && lastItem.rate === 0) {
      updateItem(lastItem.id, 'name', name);
      updateItem(lastItem.id, 'rate', rate);
      return;
    }
    setItems([...items, { id: Date.now().toString(), name, quantity: 1, rate, total: rate }]);
  };

  const removeItem = (id: string) => {
    if (items.length > 1) {
      setItems(items.filter(item => item.id !== id));
    } else {
      setItems([{ id: '1', name: '', quantity: 1, rate: 0, total: 0 }]);
    }
  };

  const updateItem = (id: string, field: keyof ProductItem, value: any) => {
    setItems(items.map(item => {
      if (item.id === id) {
        const updatedItem = { ...item, [field]: value };
        
        // If name changes, check if it matches an inventory product to auto-fill rate
        if (field === 'name') {
          const match = inventoryProducts.find(p => p.name === value);
          if (match) {
            updatedItem.rate = match.defaultRate;
          }
        }

        if (field === 'quantity' || field === 'rate' || field === 'name') {
          updatedItem.total = (updatedItem.quantity || 0) * (updatedItem.rate || 0);
        }
        return updatedItem;
      }
      return item;
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !address || !phone) {
      alert('Please fill in all customer details');
      return;
    }

    const filteredItems = items.filter(i => i.name.trim() !== '');
    if (filteredItems.length === 0) {
      alert('Please add at least one product');
      return;
    }

    const deliveryData: Delivery = {
      id: initialData ? initialData.id : Date.now().toString(),
      orderId,
      slipType,
      customerName,
      address,
      phone,
      items: filteredItems,
      weight,
      paymentMethod,
      subTotal: totals.subTotal,
      vatRate,
      vatType: 'Excluded',
      vatAmount: totals.vatAmount,
      grandTotal: totals.grandTotal,
      paymentAmount: totals.grandTotal,
      createdAt: initialData ? initialData.createdAt : Date.now(),
      status: initialData ? initialData.status : 'Pending'
    };

    onSubmit(deliveryData);
  };

  const isEditMode = !!initialData;

  return (
    <div className="animate-in slide-in-from-bottom-4 duration-500 max-w-5xl mx-auto">
      {/* Product List for Datalist */}
      <datalist id="inventory-products">
        {inventoryProducts.map(p => (
          <option key={p.id} value={p.name} />
        ))}
      </datalist>

      <div className="mb-8 flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">{isEditMode ? 'Edit Delivery Order' : 'New Delivery Order'}</h1>
          <p className="text-gray-500">
            {isEditMode ? `Updating details for Order ${orderId}.` : 'Enter order details for Global Kishan shipment.'}
          </p>
        </div>
        <div className="w-64">
           <label className="block text-xs font-bold text-[#1f7a3f] uppercase mb-1 flex items-center gap-1">
             <Tag className="w-3 h-3" /> Slip Classification
           </label>
           <select 
             value={slipType}
             onChange={(e) => setSlipType(e.target.value as SlipType)}
             className="w-full px-4 py-2 bg-white border-2 border-[#1f7a3f] rounded-xl font-bold text-[#1f7a3f] focus:ring-2 focus:ring-[#1f7a3f] outline-none"
           >
             <option value="General">Generals (सामान्य)</option>
             <option value="Sample">Samples (नमुना)</option>
             <option value="Standard">Standard (स्तर)</option>
           </select>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8 pb-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <section className="md:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-gray-100 space-y-4">
            <h2 className="text-lg font-bold text-[#1f7a3f] flex items-center gap-2 mb-4">
              <User className="w-5 h-5" />
              Customer Information
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-gray-700 mb-1">Order ID</label>
                <input 
                  type="text" 
                  value={orderId} 
                  onChange={(e) => setOrderId(e.target.value)}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#1f7a3f] outline-none font-mono font-bold text-[#1f7a3f]"
                  readOnly={isEditMode}
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1">Customer Name</label>
                <input 
                  type="text" 
                  value={customerName} 
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="Full Name"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#1f7a3f] outline-none transition-all"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1">Phone Number</label>
                <input 
                  type="tel" 
                  value={phone} 
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="98XXXXXXXX"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#1f7a3f] outline-none transition-all"
                  required
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-gray-700 mb-1">Address</label>
                <textarea 
                  value={address} 
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Full Address"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#1f7a3f] outline-none transition-all h-20 resize-none"
                  required
                />
              </div>
            </div>
          </section>

          <div className="space-y-6">
            <section className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 space-y-4">
              <h2 className="text-lg font-bold text-[#1f7a3f] flex items-center gap-2 mb-4">
                <Truck className="w-5 h-5" />
                Delivery Info
              </h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">Weight (kg)</label>
                  <input 
                    type="number" 
                    step="0.1"
                    value={weight} 
                    onChange={(e) => setWeight(parseFloat(e.target.value) || 0)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#1f7a3f] outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">Payment Type</label>
                  <div className="grid grid-cols-3 gap-2">
                    {['COD', 'Prepaid', 'Wallet'].map((method) => (
                      <button
                        key={method}
                        type="button"
                        onClick={() => setPaymentMethod(method as any)}
                        className={`py-2 px-1 rounded-lg border text-xs font-bold transition-all ${
                          paymentMethod === method 
                          ? 'bg-[#1f7a3f] text-white border-[#1f7a3f]' 
                          : 'bg-white text-gray-600 border-gray-200'
                        }`}
                      >
                        {method}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </section>

            <section className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 space-y-4 border-l-4 border-l-blue-500">
               <h2 className="text-lg font-bold text-blue-600 flex items-center gap-2 mb-4">
                <Percent className="w-5 h-5" />
                Taxation (VAT)
              </h2>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-1">VAT Percentage (%)</label>
                <select 
                  value={vatRate}
                  onChange={(e) => setVatRate(parseFloat(e.target.value))}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  <option value="0">0% (VAT Free)</option>
                  <option value="5">5% (Agri Rate)</option>
                  <option value="13">13% (Standard Rate)</option>
                </select>
              </div>
            </section>
          </div>
        </div>

        <section className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
            <h2 className="text-lg font-bold text-[#1f7a3f] flex items-center gap-2">
              <ShoppingBag className="w-5 h-5" />
              Product List
            </h2>
            <div className="flex flex-wrap gap-2 items-center">
              <span className="text-xs font-bold text-gray-400 uppercase mr-2 text-nowrap">Suggested Products:</span>
              <div className="flex flex-wrap gap-2">
                {inventoryProducts.slice(0, 5).map((sample) => (
                  <button
                    key={sample.id}
                    type="button"
                    onClick={() => addItem(sample.name, sample.defaultRate)}
                    className="text-[10px] font-bold px-3 py-1.5 rounded-full border border-green-100 bg-green-50 text-[#1f7a3f] hover:bg-[#1f7a3f] hover:text-white transition-all flex items-center gap-1"
                  >
                    <Sprout className="w-3 h-3" /> {sample.name}
                  </button>
                ))}
              </div>
            </div>
            <button 
              type="button" 
              onClick={() => addItem()}
              className="text-sm font-bold text-[#1f7a3f] hover:text-[#165a2e] flex items-center gap-1 bg-green-50 px-3 py-2 rounded-lg"
            >
              <Plus className="w-4 h-4" /> Add Row
            </button>
          </div>

          <div className="space-y-3">
            {items.map((item) => (
              <div key={item.id} className="grid grid-cols-12 gap-3 items-end animate-in slide-in-from-left-2 duration-300">
                <div className="col-span-5 relative">
                  <input 
                    type="text" 
                    list="inventory-products"
                    value={item.name} 
                    onChange={(e) => updateItem(item.id, 'name', e.target.value)}
                    placeholder="Search or Type Product Name"
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#1f7a3f] outline-none"
                    required
                  />
                  <Search className="absolute right-3 top-3 w-4 h-4 text-gray-300 pointer-events-none" />
                </div>
                <div className="col-span-2">
                  <input 
                    type="number" 
                    value={item.quantity} 
                    onChange={(e) => updateItem(item.id, 'quantity', parseFloat(e.target.value) || 0)}
                    placeholder="Qty"
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#1f7a3f] outline-none"
                    min="1"
                    required
                  />
                </div>
                <div className="col-span-2">
                  <input 
                    type="number" 
                    value={item.rate} 
                    onChange={(e) => updateItem(item.id, 'rate', parseFloat(e.target.value) || 0)}
                    placeholder="Rate"
                    className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#1f7a3f] outline-none"
                    min="0"
                    required
                  />
                </div>
                <div className="col-span-2">
                  <div className="w-full px-4 py-2.5 bg-gray-50 border border-gray-100 rounded-xl font-bold text-gray-700 text-sm">
                    {item.total.toLocaleString()}
                  </div>
                </div>
                <div className="col-span-1 flex justify-center">
                  <button 
                    type="button"
                    onClick={() => removeItem(item.id)}
                    className="p-2.5 text-red-500 hover:bg-red-50 rounded-xl transition-colors"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>

        <div className="flex flex-col md:flex-row gap-8 items-start">
          <div className="flex-1 bg-white p-6 rounded-2xl shadow-sm border border-gray-100 w-full">
             <div className="flex items-center gap-2 mb-4">
                <Calculator className="w-5 h-5 text-gray-400" />
                <h3 className="font-bold text-gray-700">Financial Breakdown</h3>
             </div>
             <div className="space-y-2">
                <div className="flex justify-between text-sm text-gray-600">
                   <span>Sub-total (Sum of Items):</span>
                   <span className="font-semibold">Rs. {totals.subTotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm text-gray-600">
                   <span>VAT Amount ({vatRate}%):</span>
                   <span className="font-semibold text-blue-600">+ Rs. {totals.vatAmount.toLocaleString()}</span>
                </div>
                <div className="pt-2 border-t border-gray-100 flex justify-between">
                   <span className="font-bold text-lg">Grand Total (Collectible):</span>
                   <span className="font-black text-2xl text-[#1f7a3f]">Rs. {totals.grandTotal.toLocaleString()}</span>
                </div>
             </div>
          </div>
          
          <button 
            type="submit"
            className={`w-full md:w-1/2 ${isEditMode ? 'bg-amber-600 hover:bg-amber-700 shadow-amber-200' : 'bg-[#1f7a3f] hover:bg-[#165a2e] shadow-green-200'} text-white py-5 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all shadow-xl text-xl`}
          >
            {isEditMode ? <RefreshCw className="w-7 h-7" /> : <Save className="w-7 h-7" />}
            {isEditMode ? 'Update Order' : 'Save Delivery Order'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default DeliveryForm;
