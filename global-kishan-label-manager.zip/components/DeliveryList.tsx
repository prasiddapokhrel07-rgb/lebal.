
import React, { useState } from 'react';
import { Printer, Trash2, Search, CheckCircle2, AlertCircle, ShoppingCart, Edit3 } from 'lucide-react';
import { Delivery } from '../types';

interface DeliveryListProps {
  deliveries: Delivery[];
  selectedForPrint: string[];
  setSelectedForPrint: (ids: string[]) => void;
  onPrint: () => void;
  onDelete: (id: string) => void;
  onEdit: (delivery: Delivery) => void;
}

const DeliveryList: React.FC<DeliveryListProps> = ({ 
  deliveries, 
  selectedForPrint, 
  setSelectedForPrint, 
  onPrint,
  onDelete,
  onEdit
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredDeliveries = deliveries.filter(d => 
    d.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    d.orderId.toLowerCase().includes(searchTerm.toLowerCase()) ||
    d.phone.includes(searchTerm)
  );

  const toggleSelect = (id: string) => {
    if (selectedForPrint.includes(id)) {
      setSelectedForPrint(selectedForPrint.filter(sid => sid !== id));
    } else {
      setSelectedForPrint([...selectedForPrint, id]);
    }
  };

  const toggleSelectAll = () => {
    if (selectedForPrint.length === filteredDeliveries.length) {
      setSelectedForPrint([]);
    } else {
      setSelectedForPrint(filteredDeliveries.map(d => d.id));
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Delivery History</h1>
          <p className="text-gray-500">View, manage and print labels for your shipments.</p>
        </div>
        
        {selectedForPrint.length > 0 && (
          <button 
            onClick={onPrint}
            className="bg-[#1f7a3f] text-white px-8 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-[#165a2e] transition-all shadow-lg animate-in zoom-in"
          >
            <Printer className="w-5 h-5" />
            Print Selected ({selectedForPrint.length})
          </button>
        )}
      </div>

      {/* Filters & Search */}
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-3.5 w-5 h-5 text-gray-400" />
          <input 
            type="text"
            placeholder="Search by customer, order ID or phone..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#1f7a3f] outline-none"
          />
        </div>
        <div className="flex gap-2">
          <div className="bg-gray-50 px-4 py-3 rounded-xl border border-gray-200 text-sm font-semibold flex items-center gap-2 text-gray-600">
            <AlertCircle className="w-4 h-4" />
            Total: {filteredDeliveries.length}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-gray-50 text-gray-500 text-xs uppercase font-bold tracking-wider">
                <th className="px-6 py-4 w-12">
                  <input 
                    type="checkbox" 
                    checked={selectedForPrint.length > 0 && selectedForPrint.length === filteredDeliveries.length}
                    onChange={toggleSelectAll}
                    className="w-4 h-4 rounded text-[#1f7a3f] focus:ring-[#1f7a3f] cursor-pointer"
                  />
                </th>
                <th className="px-6 py-4">Order Details</th>
                <th className="px-6 py-4">Customer</th>
                <th className="px-6 py-4">Items</th>
                <th className="px-6 py-4">Weight/Cost</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredDeliveries.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-20 text-center text-gray-400">
                    <ShoppingCart className="w-16 h-16 mx-auto mb-4 opacity-10" />
                    <p className="text-lg">No matching deliveries found.</p>
                  </td>
                </tr>
              ) : (
                filteredDeliveries.map((delivery) => (
                  <tr key={delivery.id} className={`hover:bg-gray-50 transition-colors ${selectedForPrint.includes(delivery.id) ? 'bg-green-50' : ''}`}>
                    <td className="px-6 py-4">
                      <input 
                        type="checkbox" 
                        checked={selectedForPrint.includes(delivery.id)}
                        onChange={() => toggleSelect(delivery.id)}
                        className="w-4 h-4 rounded text-[#1f7a3f] focus:ring-[#1f7a3f] cursor-pointer"
                      />
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm font-mono font-bold text-[#1f7a3f]">{delivery.orderId}</div>
                      <div className="text-xs text-gray-500 mt-0.5">{new Date(delivery.createdAt).toLocaleString()}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm font-bold text-gray-900">{delivery.customerName}</div>
                      <div className="text-xs text-gray-500">{delivery.phone}</div>
                      <div className="text-xs text-gray-400 truncate max-w-xs">{delivery.address}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-xs font-semibold text-gray-600">
                        {delivery.items.length > 0 
                          ? delivery.items.map(i => `${i.name} (${i.quantity})`).join(', ') 
                          : 'No items'}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm font-bold text-gray-900">{delivery.weight} kg</div>
                      <div className="text-xs font-bold text-gray-500 mt-0.5">Rs. {delivery.paymentAmount} ({delivery.paymentMethod})</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-1.5">
                        {delivery.status === 'Printed' ? (
                          <div className="bg-green-100 text-green-700 px-2 py-0.5 rounded-full text-xs font-bold flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" /> Printed
                          </div>
                        ) : (
                          <div className="bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full text-xs font-bold">
                            Pending
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end gap-2">
                        <button 
                          onClick={() => onEdit(delivery)}
                          className="p-2 text-amber-500 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-all"
                          title="Edit Order"
                        >
                          <Edit3 className="w-5 h-5" />
                        </button>
                        <button 
                          onClick={() => onDelete(delivery.id)}
                          className="p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                          title="Delete Order"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default DeliveryList;
