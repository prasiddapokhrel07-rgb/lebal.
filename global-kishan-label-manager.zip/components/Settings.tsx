
import React, { useRef } from 'react';
import { Save, Building2, MapPin, Phone, Mail, Globe, Upload, Quote } from 'lucide-react';
import { CompanySettings } from '../types';

interface SettingsProps {
  settings: CompanySettings;
  onUpdate: (settings: CompanySettings) => void;
}

const Settings: React.FC<SettingsProps> = ({ settings, onUpdate }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleChange = (field: keyof CompanySettings, value: string) => {
    onUpdate({ ...settings, [field]: value });
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        handleChange('logo', reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="animate-in fade-in duration-500 max-w-3xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Store Settings</h1>
        <p className="text-gray-500">Customize label branding and company details.</p>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-8 border-b border-gray-100 bg-gray-50">
          <div className="flex flex-col items-center">
            <div className="relative group mb-4">
              <div className="w-32 h-32 rounded-2xl overflow-hidden border-4 border-white shadow-xl bg-white">
                <img 
                  src={settings.logo} 
                  alt="Company Logo" 
                  className="w-full h-full object-contain"
                />
              </div>
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-2xl text-white flex-col gap-1"
              >
                <Upload className="w-6 h-6" />
                <span className="text-xs font-bold">Change Logo</span>
              </button>
              <input 
                ref={fileInputRef}
                type="file" 
                accept="image/*" 
                onChange={handleLogoUpload}
                className="hidden"
              />
            </div>
            <h2 className="text-xl font-bold text-gray-900">{settings.name}</h2>
            <p className="text-[#1f7a3f] font-semibold">{settings.tagline || 'Agricultural Auto Delivery System'}</p>
          </div>
        </div>

        <div className="p-8 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1 flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-gray-400" /> Store Name
                </label>
                <input 
                  type="text" 
                  value={settings.name} 
                  onChange={(e) => handleChange('name', e.target.value)}
                  placeholder="Company Name"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#1f7a3f] outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1 flex items-center gap-2">
                  <Quote className="w-4 h-4 text-gray-400" /> Company Tagline
                </label>
                <input 
                  type="text" 
                  value={settings.tagline} 
                  onChange={(e) => handleChange('tagline', e.target.value)}
                  placeholder="Empowering Agriculture..."
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#1f7a3f] outline-none font-italic"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1 flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-gray-400" /> Address
                </label>
                <input 
                  type="text" 
                  value={settings.address} 
                  onChange={(e) => handleChange('address', e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#1f7a3f] outline-none"
                />
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1 flex items-center gap-2">
                  <Phone className="w-4 h-4 text-gray-400" /> Contact Number
                </label>
                <input 
                  type="text" 
                  value={settings.phone} 
                  onChange={(e) => handleChange('phone', e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#1f7a3f] outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1 flex items-center gap-2">
                  <Mail className="w-4 h-4 text-gray-400" /> Email Address
                </label>
                <input 
                  type="email" 
                  value={settings.email} 
                  onChange={(e) => handleChange('email', e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#1f7a3f] outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1 flex items-center gap-2">
                  <Globe className="w-4 h-4 text-gray-400" /> Website URL
                </label>
                <input 
                  type="text" 
                  value={settings.website} 
                  onChange={(e) => handleChange('website', e.target.value)}
                  placeholder="https://globalkishanauto.com"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#1f7a3f] outline-none"
                />
              </div>
            </div>
          </div>

          <div className="pt-6 border-t border-gray-100">
            <button className="w-full bg-[#1f7a3f] text-white py-4 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-[#165a2e] transition-all shadow-lg">
              <Save className="w-5 h-5" />
              Save Configuration
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;
