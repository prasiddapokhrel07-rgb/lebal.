
import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  PlusCircle, 
  List, 
  Settings as SettingsIcon, 
  LogOut, 
  Sprout, 
  Printer,
  ChevronRight,
  User,
  X,
  Check,
  Mail,
  Lock,
  ArrowLeft,
  Store,
  Box
} from 'lucide-react';
import Dashboard from './components/Dashboard';
import DeliveryForm from './components/DeliveryForm';
import DeliveryList from './components/DeliveryList';
import Settings from './components/Settings';
import Inventory from './components/Inventory';
import LabelPrintView from './components/LabelPrintView';
import { Delivery, CompanySettings, ViewType, InventoryProduct } from './types';

const STORAGE_KEY_DELIVERIES = 'gk_deliveries';
const STORAGE_KEY_SETTINGS = 'gk_settings';
const STORAGE_KEY_PRODUCTS = 'gk_products';
const ADMIN_PASSWORD = 'admin';

type AuthMode = 'login' | 'register' | 'reset';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [authMode, setAuthMode] = useState<AuthMode>('login');
  const [loginError, setLoginError] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [view, setView] = useState<ViewType>('dashboard');
  const [deliveries, setDeliveries] = useState<Delivery[]>([]);
  const [products, setProducts] = useState<InventoryProduct[]>([]);
  const [editingDelivery, setEditingDelivery] = useState<Delivery | null>(null);
  const [settings, setSettings] = useState<CompanySettings>({
    name: 'Global Kishan Agricultural Auto',
    tagline: 'Empowering Agriculture through Quality Deliveries',
    address: 'Kathmandu, Nepal',
    phone: '+977-9800000000',
    email: 'info@globalkishanauto.com',
    website: 'https://globalkishanauto.com',
    logo: 'https://images.unsplash.com/photo-1595841055318-502621815152?auto=format&fit=crop&q=80&w=200&h=200'
  });
  const [selectedForPrint, setSelectedForPrint] = useState<string[]>([]);
  const [isPrinting, setIsPrinting] = useState<boolean>(false);
  const [showPreview, setShowPreview] = useState<boolean>(false);

  useEffect(() => {
    const savedDeliveries = localStorage.getItem(STORAGE_KEY_DELIVERIES);
    if (savedDeliveries) setDeliveries(JSON.parse(savedDeliveries));

    const savedSettings = localStorage.getItem(STORAGE_KEY_SETTINGS);
    if (savedSettings) setSettings(JSON.parse(savedSettings));

    const savedProducts = localStorage.getItem(STORAGE_KEY_PRODUCTS);
    if (savedProducts) {
      setProducts(JSON.parse(savedProducts));
    } else {
      // Default sample products
      const defaults: InventoryProduct[] = [
        { id: '1', name: 'Tomato Seeds', defaultRate: 150 },
        { id: '2', name: 'Organic Fertilizer', defaultRate: 850 },
        { id: '3', name: 'Urea (50kg)', defaultRate: 1200 },
      ];
      setProducts(defaults);
    }

    const auth = sessionStorage.getItem('gk_auth');
    if (auth === 'true') setIsAuthenticated(true);
  }, []);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_DELIVERIES, JSON.stringify(deliveries));
  }, [deliveries]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PRODUCTS, JSON.stringify(products));
  }, [products]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD || password === '1234') {
      setIsAuthenticated(true);
      sessionStorage.setItem('gk_auth', 'true');
      setLoginError('');
    } else {
      setLoginError('Incorrect password. Please try "admin" or "1234".');
    }
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Registration successful! Please login with your password.');
    setAuthMode('login');
  };

  const handleResetPassword = (e: React.FormEvent) => {
    e.preventDefault();
    alert(`A password reset link has been sent to ${email} via Gmail.`);
    setAuthMode('login');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem('gk_auth');
  };

  const saveDelivery = (delivery: Delivery) => {
    const exists = deliveries.find(d => d.id === delivery.id);
    if (exists) {
      setDeliveries(prev => prev.map(d => d.id === delivery.id ? delivery : d));
    } else {
      setDeliveries([delivery, ...deliveries]);
    }
    setEditingDelivery(null);
    setView('list');
  };

  const startEditing = (delivery: Delivery) => {
    setEditingDelivery(delivery);
    setView('edit');
  };

  const updateDeliveryStatus = (id: string, status: Delivery['status']) => {
    setDeliveries(prev => prev.map(d => d.id === id ? { ...d, status } : d));
  };

  const deleteDelivery = (id: string) => {
    setDeliveries(prev => prev.filter(d => d.id !== id));
    setSelectedForPrint(prev => prev.filter(sid => sid !== id));
  };

  const handleOpenPreview = () => {
    if (selectedForPrint.length === 0) return;
    setShowPreview(true);
  };

  const executePrint = () => {
    setIsPrinting(true);
    setShowPreview(false);
    setTimeout(() => {
      window.print();
      setIsPrinting(false);
      selectedForPrint.forEach(id => updateDeliveryStatus(id, 'Printed'));
      setSelectedForPrint([]);
    }, 500);
  };

  const handleNavAdd = () => {
    setEditingDelivery(null);
    setView('add');
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#1f7a3f] flex items-center justify-center px-4 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-white/10 rounded-full -mr-48 -mt-48 blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-black/10 rounded-full -ml-48 -mb-48 blur-3xl"></div>

        <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden relative z-10 transition-all duration-500 animate-in zoom-in-95">
          <div className="bg-gray-50 px-8 py-10 flex flex-col items-center border-b border-gray-100">
            <div className="relative mb-6">
              <div className="w-24 h-24 rounded-2xl bg-white shadow-xl p-2 border border-gray-100 overflow-hidden">
                <img 
                  src={settings.logo} 
                  alt="Global Kishan Logo" 
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="absolute -bottom-2 -right-2 bg-[#1f7a3f] p-1.5 rounded-lg shadow-lg">
                <Sprout className="w-5 h-5 text-white" />
              </div>
            </div>
            <h1 className="text-2xl font-black text-gray-900 tracking-tight">{settings.name}</h1>
            <p className="text-gray-500 text-sm font-medium mt-1 uppercase tracking-widest">{settings.tagline}</p>
          </div>
          
          <div className="p-8">
            {authMode === 'login' && (
              <form onSubmit={handleLogin} className="space-y-5">
                <div className="text-center mb-6">
                  <h2 className="text-xl font-bold text-gray-800">Welcome Back</h2>
                  <p className="text-gray-400 text-sm">Sign in to your delivery account</p>
                </div>
                <div className="relative">
                  <Mail className="absolute left-4 top-3.5 w-5 h-5 text-gray-400" />
                  <input 
                    type="email"
                    placeholder="Email Address"
                    className="w-full pl-12 pr-4 py-3.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#1f7a3f] outline-none transition-all"
                    required
                  />
                </div>
                <div className="relative">
                  <Lock className="absolute left-4 top-3.5 w-5 h-5 text-gray-400" />
                  <input 
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Password"
                    className="w-full pl-12 pr-4 py-3.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#1f7a3f] outline-none transition-all"
                    required
                  />
                </div>
                {loginError && <p className="text-red-500 text-xs font-bold text-center bg-red-50 py-2 rounded-lg">{loginError}</p>}
                
                <div className="flex items-center justify-between text-sm">
                  <label className="flex items-center gap-2 text-gray-500 cursor-pointer">
                    <input type="checkbox" className="w-4 h-4 rounded text-[#1f7a3f] focus:ring-[#1f7a3f]" />
                    Remember me
                  </label>
                  <button 
                    type="button" 
                    onClick={() => setAuthMode('reset')}
                    className="text-[#1f7a3f] font-bold hover:underline"
                  >
                    Forgot Password?
                  </button>
                </div>

                <button 
                  type="submit"
                  className="w-full bg-[#1f7a3f] hover:bg-[#165a2e] text-white font-bold py-4 rounded-xl transition-all shadow-xl shadow-green-100 flex items-center justify-center gap-2 text-lg"
                >
                  Sign In
                </button>

                <div className="text-center pt-4 border-t border-gray-100">
                  <p className="text-gray-500 text-sm">
                    New to Global Kishan? {' '}
                    <button 
                      type="button" 
                      onClick={() => setAuthMode('register')}
                      className="text-[#1f7a3f] font-bold hover:underline"
                    >
                      Create Account
                    </button>
                  </p>
                </div>
              </form>
            )}

            {authMode === 'register' && (
              <form onSubmit={handleRegister} className="space-y-4">
                <div className="text-center mb-4">
                  <h2 className="text-xl font-bold text-gray-800">Register Store</h2>
                  <p className="text-gray-400 text-sm">Join the Global Kishan platform</p>
                </div>
                <div className="relative">
                  <User className="absolute left-4 top-3.5 w-5 h-5 text-gray-400" />
                  <input 
                    type="text"
                    placeholder="Full Name"
                    className="w-full pl-12 pr-4 py-3.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#1f7a3f] outline-none"
                    required
                  />
                </div>
                <div className="relative">
                  <Store className="absolute left-4 top-3.5 w-5 h-5 text-gray-400" />
                  <input 
                    type="text"
                    placeholder="Store/Company Name"
                    className="w-full pl-12 pr-4 py-3.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#1f7a3f] outline-none"
                    required
                  />
                </div>
                <div className="relative">
                  <Mail className="absolute left-4 top-3.5 w-5 h-5 text-gray-400" />
                  <input 
                    type="email"
                    placeholder="Email Address"
                    className="w-full pl-12 pr-4 py-3.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#1f7a3f] outline-none"
                    required
                  />
                </div>
                <div className="relative">
                  <Lock className="absolute left-4 top-3.5 w-5 h-5 text-gray-400" />
                  <input 
                    type="password"
                    placeholder="Create Password"
                    className="w-full pl-12 pr-4 py-3.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#1f7a3f] outline-none"
                    required
                  />
                </div>
                <button 
                  type="submit"
                  className="w-full bg-[#1f7a3f] hover:bg-[#165a2e] text-white font-bold py-4 rounded-xl transition-all shadow-lg"
                >
                  Create Account
                </button>
                <div className="text-center pt-2">
                  <button 
                    type="button" 
                    onClick={() => setAuthMode('login')}
                    className="text-[#1f7a3f] font-bold text-sm flex items-center justify-center gap-1 mx-auto"
                  >
                    <ArrowLeft className="w-4 h-4" /> Back to Login
                  </button>
                </div>
              </form>
            )}

            {authMode === 'reset' && (
              <form onSubmit={handleResetPassword} className="space-y-6">
                <div className="text-center mb-4">
                  <h2 className="text-xl font-bold text-gray-800">Reset Password</h2>
                  <p className="text-gray-400 text-sm">We'll send a recovery link via Gmail</p>
                </div>
                <div className="relative">
                  <Mail className="absolute left-4 top-3.5 w-5 h-5 text-gray-400" />
                  <input 
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Your Email Address"
                    className="w-full pl-12 pr-4 py-3.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#1f7a3f] outline-none"
                    required
                  />
                </div>
                <button 
                  type="submit"
                  className="w-full bg-[#1f7a3f] hover:bg-[#165a2e] text-white font-bold py-4 rounded-xl transition-all shadow-lg"
                >
                  Send Reset Link (Gmail)
                </button>
                <div className="text-center">
                  <button 
                    type="button" 
                    onClick={() => setAuthMode('login')}
                    className="text-[#1f7a3f] font-bold text-sm flex items-center justify-center gap-1 mx-auto"
                  >
                    <ArrowLeft className="w-4 h-4" /> I remember my password
                  </button>
                </div>
              </form>
            )}
          </div>
          <div className="p-6 bg-gray-50 border-t border-gray-100 flex justify-center gap-4 text-xs font-bold text-gray-400 uppercase tracking-widest">
            <span>Security</span>
            <span>•</span>
            <span>Privacy</span>
            <span>•</span>
            <span>Support</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex bg-gray-50">
      {(isPrinting || showPreview) && (
        <div id="print-area" className={showPreview ? 'no-print hidden' : ''}>
          <LabelPrintView 
            deliveries={deliveries.filter(d => selectedForPrint.includes(d.id))}
            settings={settings}
          />
        </div>
      )}

      {showPreview && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 no-print">
          <div className="bg-gray-100 w-full max-w-5xl h-[90vh] rounded-3xl shadow-2xl overflow-hidden flex flex-col">
            <header className="bg-white px-8 py-4 flex justify-between items-center border-b">
              <div>
                <h2 className="text-xl font-bold text-gray-900">Label Print Preview</h2>
                <p className="text-sm text-gray-500">{selectedForPrint.length} labels selected for printing</p>
              </div>
              <div className="flex gap-3">
                <button 
                  onClick={() => setShowPreview(false)}
                  className="px-5 py-2.5 rounded-xl border border-gray-200 font-bold text-gray-600 hover:bg-gray-50 transition-all flex items-center gap-2"
                >
                  <X className="w-5 h-5" /> Cancel
                </button>
                <button 
                  onClick={executePrint}
                  className="px-6 py-2.5 rounded-xl bg-[#1f7a3f] font-bold text-white hover:bg-[#165a2e] transition-all flex items-center gap-2 shadow-lg shadow-green-200"
                >
                  <Printer className="w-5 h-5" /> Confirm & Print
                </button>
              </div>
            </header>
            
            <div className="flex-1 overflow-y-auto p-12 flex justify-center bg-gray-200">
               <div className="bg-white shadow-2xl origin-top transform scale-[0.6] sm:scale-[0.8] lg:scale-[1.0]">
                  <LabelPrintView 
                    deliveries={deliveries.filter(d => selectedForPrint.includes(d.id))}
                    settings={settings}
                  />
               </div>
            </div>
          </div>
        </div>
      )}

      <nav className="w-64 bg-white border-r border-gray-200 flex flex-col no-print fixed h-full z-10">
        <div className="p-6 flex items-center gap-3 border-b border-gray-50">
          <div className="bg-[#1f7a3f] p-2 rounded-lg">
            <Sprout className="w-6 h-6 text-white" />
          </div>
          <span className="font-bold text-xl text-[#1f7a3f]">Global Kishan</span>
        </div>
        
        <div className="flex-1 px-4 py-6 space-y-2">
          <button 
            onClick={() => setView('dashboard')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${view === 'dashboard' ? 'bg-[#1f7a3f] text-white shadow-md' : 'text-gray-600 hover:bg-gray-100'}`}
          >
            <LayoutDashboard className="w-5 h-5" />
            <span className="font-medium">Dashboard</span>
          </button>
          
          <button 
            onClick={handleNavAdd}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${view === 'add' || view === 'edit' ? 'bg-[#1f7a3f] text-white shadow-md' : 'text-gray-600 hover:bg-gray-100'}`}
          >
            <PlusCircle className="w-5 h-5" />
            <span className="font-medium">{view === 'edit' ? 'Editing Order' : 'New Delivery'}</span>
          </button>
          
          <button 
            onClick={() => setView('list')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${view === 'list' ? 'bg-[#1f7a3f] text-white shadow-md' : 'text-gray-600 hover:bg-gray-100'}`}
          >
            <List className="w-5 h-5" />
            <span className="font-medium">Order History</span>
          </button>

          <button 
            onClick={() => setView('inventory')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${view === 'inventory' ? 'bg-[#1f7a3f] text-white shadow-md' : 'text-gray-600 hover:bg-gray-100'}`}
          >
            <Box className="w-5 h-5" />
            <span className="font-medium">Products (माल)</span>
          </button>
          
          <div className="pt-4 border-t border-gray-100 mt-4">
            <button 
              onClick={() => setView('settings')}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${view === 'settings' ? 'bg-[#1f7a3f] text-white shadow-md' : 'text-gray-600 hover:bg-gray-100'}`}
            >
              <SettingsIcon className="w-5 h-5" />
              <span className="font-medium">Settings</span>
            </button>
          </div>
        </div>

        <div className="p-4 border-t border-gray-100">
          <div className="flex items-center gap-3 px-4 py-3 mb-4 bg-gray-50 rounded-xl">
            <div className="w-10 h-10 rounded-full bg-green-200 flex items-center justify-center text-[#1f7a3f]">
              <User className="w-6 h-6" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-gray-900 truncate">Admin User</p>
              <p className="text-xs text-gray-500">Manager</p>
            </div>
          </div>
          <button 
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-600 hover:bg-red-50 transition-all"
          >
            <LogOut className="w-5 h-5" />
            <span className="font-medium">Logout</span>
          </button>
        </div>
      </nav>

      <main className="flex-1 ml-64 p-8 no-print min-h-screen">
        <div className="max-w-6xl mx-auto">
          {view === 'dashboard' && (
            <Dashboard 
              deliveries={deliveries} 
              onNewOrder={handleNavAdd} 
              onViewAll={() => setView('list')}
              settings={settings}
            />
          )}
          {(view === 'add' || view === 'edit') && (
            <DeliveryForm 
              onSubmit={saveDelivery} 
              initialData={editingDelivery} 
              inventoryProducts={products}
            />
          )}
          {view === 'list' && (
            <DeliveryList 
              deliveries={deliveries} 
              selectedForPrint={selectedForPrint}
              setSelectedForPrint={setSelectedForPrint}
              onPrint={handleOpenPreview}
              onDelete={deleteDelivery}
              onEdit={startEditing}
            />
          )}
          {view === 'inventory' && (
            <Inventory products={products} onUpdate={setProducts} />
          )}
          {view === 'settings' && (
            <Settings settings={settings} onUpdate={setSettings} />
          )}
        </div>
      </main>
    </div>
  );
};

export default App;
