
export interface ProductItem {
  id: string;
  name: string;
  quantity: number;
  rate: number;
  total: number;
}

export interface InventoryProduct {
  id: string;
  name: string;
  defaultRate: number;
  category?: string;
}

export type SlipType = 'Sample' | 'General' | 'Standard';

export interface Delivery {
  id: string;
  orderId: string;
  slipType: SlipType;
  customerName: string;
  address: string;
  phone: string;
  items: ProductItem[];
  weight: number;
  paymentMethod: 'COD' | 'Prepaid' | 'Wallet';
  subTotal: number;
  vatRate: number; // e.g., 13
  vatType: 'Excluded';
  vatAmount: number;
  grandTotal: number;
  paymentAmount: number;
  createdAt: number;
  status: 'Pending' | 'Printed' | 'Shipped';
}

export interface CompanySettings {
  name: string;
  tagline: string;
  address: string;
  phone: string;
  email: string;
  website: string;
  logo: string; // base64 string
}

export type ViewType = 'dashboard' | 'add' | 'edit' | 'list' | 'settings' | 'inventory';
